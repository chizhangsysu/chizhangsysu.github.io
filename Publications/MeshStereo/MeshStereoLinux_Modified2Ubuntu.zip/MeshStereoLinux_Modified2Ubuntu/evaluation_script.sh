
inputDataPath="./"

./build/mainMeshStereo ${inputDataPath}"/im0.png" ${inputDataPath}"/im1.png" ${inputDataPath}"/dispRes.png" 128
